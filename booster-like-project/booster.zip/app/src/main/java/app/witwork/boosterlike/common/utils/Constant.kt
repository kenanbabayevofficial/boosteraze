package app.witwork.boosterlike.common.utils

object ProductSku {
    var skuList = mutableListOf<String>()
}

object SharePref {
    const val KEY_FEED_ID = "KEY_FEED_ID"
    const val KEY_USER_ID = "KEY_USER_ID"
}