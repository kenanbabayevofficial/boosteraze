package app.witwork.boosterlike.presentation.profile

import app.witwork.boosterlike.common.base.BaseView

interface ProfileView : BaseView {
    fun onRewardVideoSuccess()
    fun onFollowSuccess()
}